package figurasplanas;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        int	i;
        
        FigPlanas vf[]=new FigPlanas [20];
        
        vf[0] = new Quadrado ("Quadrado", 2);
        vf[1] = new Circulo ("Circulo", 4);
        vf[2] = new Retangulo ("Retangulo", 3, 2 );
        vf[3] = new Quadrado ("Quadrado", 2);
        vf[4] = new Circulo ("Circulo", 10);
        vf[5] = new Retangulo ("Retangulo", 3, 7);
        vf[6] = new Quadrado ("Quadrado", 8);
        vf[7] = new Circulo ("Circulo", 1);
        vf[8] = new Triangulo ("Triangulo", 3, 3);
        vf[9] = new Quadrado ("Quadrado", 9);
        vf[10] = new Circulo ("Circulo", 2);
        vf[11] = new Circulo ("Circulo", 5);
        vf[12] = new Retangulo ("Retangulo", 4, 2);
        vf[13] = new Quadrado ("Quadrado", 6);
        vf[14] = new Circulo ("Circulo", 7);
        vf[15] = new Retangulo ("Retangulo", 9, 2);
        vf[16] = new Quadrado ("Quadrado", 3);
        vf[17] = new Circulo ("Circulo", 8);
        vf[18] = new Retangulo ("Retangulo", 3, 9);
        vf[19] = new Quadrado ("Quadrado", 9);

        for (i=0; i<20; i++) System.out.println(vf[i]);
        }
    }
