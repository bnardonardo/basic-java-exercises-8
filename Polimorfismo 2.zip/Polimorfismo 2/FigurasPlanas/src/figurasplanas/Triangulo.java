package figurasplanas;

public class Triangulo extends FigPlanas {
    private double base; 
    private double altura;
    
    public Triangulo (String nome, double base, double altura){
        super(nome);
        this.base=(base<=0?1:base);
        this.altura=(altura<=0?1:altura);
    }
    
    public double getBase(){
        return base;
    }
    
    public void setBase(double base){
         if(base<=0) this.base=1;
        else this.base=base;
    }
    
        public double getAltuta(){
        return altura;
    }
    
    public void setAltura(double altura){
         if(altura<=0) this.altura=1;
        else this.altura=altura;
    }
    
    @Override
    public double area (){
         return (base*altura)/2;
    }
    
    @Override
    public String dados(){
         return String.format ("Base: %.2f\nAltura: %.2f", base, altura);
    }
}
