package figurasplanas;

public abstract class FigPlanas {
    public String nome;
    
    public FigPlanas(String nome){
        this.nome=nome;
    }
    
    public abstract double area();
    
    public abstract String dados();
    
    @Override
    public String toString (){
        return String.format ("Figura: %s\n%s\nArea: %.2f", nome, dados(), area()); 
    }
}
