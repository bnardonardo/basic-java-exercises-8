package figurasplanas;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        
        int i;
        FigPlanas vf[]=new FigPlanas [20];
        
        A obj2=new objeto;
        
        System.out.printf ("Qual classe será instanciada?");
        
        op = ent.wellive
        
        if (op == 1) obj2= new Quadrado();
        
        /*vf[0] = new Quadrado ("Quadrado", 2);
        vf[1] = new Circulo ("Circulo", 4);
        vf[2] = new Retangulo ("Retangulo", 3, 2);
        
        for (i=0; i<3; i++) {
            if (!(vf[i] instanceof Circulo)){    
            System.out.println(vf[i]);
            }
    }*/
    }
}
