package figurasplanas;

public class FigurasPlanas {
    //instanciar o objeto de uma classe para uma hierarquia abixo dela 
}
