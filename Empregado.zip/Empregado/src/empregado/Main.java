package empregado;

public class Main {
    
    
    public static void main(String[] args) {
        int i;
        System.out.println("Hello, World!");
        Empregado vf[]=new Empregado [10];
        
        vf[0]=new Assalariado ("José", 12345678, 2010, 3750.64);        
        vf[1]=new Comissionado ("João", 32145678, 2019, 5050.00);
        vf[2]=new AssalariadoComissionado ("Maria", 12346578, 2008, 2750.84, 1100.90);
        vf[3]=new Assalariado ("Brenda", 12345888, 2016, 3880.64);
        vf[4]=new Comissionado ("Joaquin", 36645678, 2009, 9050.00);
        vf[5]=new AssalariadoComissionado ("Ana", 12006578, 2018, 3750.84, 1000.90);
        vf[6]=new Comissionado ("Jones", 36649978, 2003, 29050.00);
        vf[7]=new AssalariadoComissionado ("Catarina", 76006578, 1998, 2750.84, 61000.90);
        vf[8]=new Assalariado ("Meire", 12345678, 2010, 3750.64);        
        vf[9]=new Comissionado ("Marta", 32145678, 2019, 5050.00);

        for(i=0; i<10; i++) System.out.println (vf[i]);        
    }
    
}
