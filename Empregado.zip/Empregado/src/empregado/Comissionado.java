package empregado;

public class Comissionado extends Empregado{
    public double TotalVendas;
    
    public Comissionado (String nome, int cpf, int dataContratacao, double TotalVendas){
        super(nome, cpf, dataContratacao);
        this.TotalVendas=TotalVendas;
    }
    
    public double getTotal(){
        return TotalVendas;
    }
    
    public void setTotal(){
        this.TotalVendas=TotalVendas;
    }
    
    public double rendimentos(){
       return (TotalVendas/10);
    }
        @Override
    public String toString (){
        return String.format ("%s, tem rendimentos de %.2f e pela tabela deve reduzir %.4f", super.toString(), rendimentos(), super.irpf()); 
    }
}
